# JavaSimpleFlight
Final project option for java class
